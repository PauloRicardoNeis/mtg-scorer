# Handoff: Archetypes & Decklists pages

## Overview
Two new sections for the constructed-format site (`web/`, Next.js App Router), with a detail page for each:

1. **Archetypes**: the metagame for one format. A sortable archetype table, a share × win-rate "meta map", share over time, and a full matchup matrix. Each archetype has a detail page with core cards, flex slots (win rate with vs. without each card), matchups and top lists.
2. **Decklists**: recent tournament lists for one format, filterable and searchable (including by card name). Each decklist has a detail page with main deck and sideboard (text or visual view), mana curve, type breakdown, paper and MTGO prices, the difference from the archetype's average list, export (Arena / MTGO / Text), a copyable share link, and card previews on hover.

Both sections work for all seven formats (Standard, Pioneer, Modern, Legacy, Vintage, Pauper, Commander). Commander (cEDH) changes labels and rules. See "Format rules" below.

Live design (claude.ai, may require login): https://claude.ai/design/p/cd971fb3-6f54-4b06-9112-02fc89195645?file=Card+Rankings.dc.html&via=share

## About the design files
The files in `design/` are **design references built in HTML**. They are prototypes that show the intended look and behavior. They are not production code to copy. Recreate them in this codebase's environment: Next.js App Router, server components that read through `web/src/lib/api.ts`, the existing components in `web/src/components/` (`mana.tsx`, `card-image.tsx`, `filters.tsx`, `toast.tsx`, `tooltip.tsx`, `site-nav.tsx`, `header-search.tsx`), and the CSS tokens already in `web/src/app/tokens.css` / `styles.css`.

To view the prototype offline, open `design/Card Rankings.dc.html` in a browser. Keep `support.js`, `styles.css`, `tokens/` and `fonts/` next to it. Use the top nav to switch between **Decklists** and **Archetypes**, and click rows to open detail pages. All numbers in the prototype are **sample data**.

## Fidelity
**High fidelity.** The colors, type, spacing, states and copy are final. The site's visual system ("Arcane & modern", already applied by the earlier `design_handoff_mtg_scorer` restyle) is the source of truth. Use the existing tokens and classes, not hard-coded values, wherever an equivalent exists.

## Data: what exists vs. what these pages need
The Java API (`/api/v1`, typed in `web/src/lib/api.generated.ts`) currently serves cards, printings, snapshots and rankings. `RankedCard` has `archetype_label` and `archetype_deck_count`, and there is a `TournamentEvidence` schema. **There are no archetype, matchup or decklist endpoints.**

Do this:
- Add the view-model types below to a new `web/src/lib/metagame.ts`, plus `api.archetypes(...)`, `api.archetype(...)`, `api.decklists(...)` and `api.decklist(...)` functions with the same shape as the existing `read<T>()` calls.
- Until the backend exposes these, back the functions with a typed fixture module (`web/src/lib/metagame.fixtures.ts`). Show the existing "Sample data" pill in each hero. Don't invent backend endpoints or change the Java service unless asked.

```ts
type Color = "W" | "U" | "B" | "R" | "G";
type CardType = "creature" | "planeswalker" | "instant" | "sorcery" | "artifact" | "enchantment" | "battle" | "land";

interface ArchetypeStat {
  id: string;               // slug, e.g. "boros-energy"
  name: string;             // "Boros Energy" (Commander: commander name or "A // B")
  colors: Color[];          // WUBRG order; [] = colorless
  share: number;            // % of decklists in window
  win_rate: number;         // %, mirrors excluded (cEDH: pod win rate)
  win_rate_ci: number;      // ± at 95%
  top_cut_lift: number;     // Top 8 (cEDH Top 16) conversion, 1.00 = field
  sample: number;           // matches (cEDH: seats)
  deck_count: number;
  share_series: number[];   // 14 weekly points, oldest → newest
  win_rate_series: number[];// 14 weekly points
  trend_30d: number;        // share now − share 30 days ago, in points
}
interface Matchup { row: string; col: string; win_rate: number; sample: number } // row archetype vs col
interface ArchetypeCard {
  name: string; mana_cost: string; type: CardType;
  inclusion: number;        // % of the archetype's lists
  avg_copies: number;       // in lists that run it
  win_rate_with?: number; sample_with?: number;      // flex cards only
  win_rate_without?: number; sample_without?: number;
}
interface DeckSummary {
  id: string; format: string; archetype_id: string; archetype: string; colors: Color[];
  player: string; event: string; event_kind: "challenge" | "league" | "paper";
  online: boolean; date: string; players: number | null;
  finish: string;           // "1st" | "2nd" | "3rd" | "Top 4" | "Top 8" | "Top 16" | "5-0" | "Trophy"
  finish_rank: number;      // 0 = winner; leagues sort after Top 8
  record: string;           // "8-1", cEDH "4-1-2" (W-L-D)
  price_usd: number; price_tix: number;
}
interface DeckCard { name: string; count: number; mana_cost: string; type: CardType; price_usd: number; price_tix: number }
interface Decklist extends DeckSummary {
  commanders: DeckCard[];   // Commander only
  main: DeckCard[]; sideboard: DeckCard[];
  diff_vs_average: { zone: "main" | "side"; name: string; delta: number }[];
}
```

## Routes, navigation and shell
New routes, each reading `format`, `window` and `source` from search params the same way `/rankings` does:

| Route | Screen |
|---|---|
| `/archetypes?format=modern` | Archetypes index |
| `/archetypes/[archetype]?format=modern` | Archetype detail |
| `/archetypes/[archetype]/average?format=modern` | Average list (rendered with the decklist detail view) |
| `/decklists?format=modern&event=&archetype=&finish=&sort=&q=` | Decklists index |
| `/decklists/[deck_id]` | Decklist detail. This is the URL the "Copy link" button copies. |

- **Site nav** (`site-nav.tsx`): add `{ href: "/decklists", label: "Decklists" }` and `{ href: "/archetypes", label: "Archetypes" }` before Methodology. Active state uses the existing `aria-current` underline (inset 0 −2px 0 accent).
- **Header width:** the prototype originally clipped the nav at about 920px. The fix was a nav `column-gap: clamp(12px, 1.6vw, 24px)` and a search box at `flex: 0 1 240px; min-width: 120px`. All links except Methodology must stay on the first row at 900px or wider.
- **Format tab strip:** reuse the rankings one. Clicking a format keeps the user in the current section (on `/archetypes/*` it goes to `/archetypes?format=…`, on `/decklists/*` to `/decklists?format=…`) and resets the archetype filter.
- **Header search:** placeholder is "Search archetypes" in Archetypes and "Search player, deck or card" in Decklists. Typing on a detail page returns to that section's index with the query applied.
- Page container: `max-width: 1440px; margin: 0 auto; padding: 0 32px`. The footer is unchanged.

## Format rules
- **1v1 formats:** baseline 50%, label "Win rate", cut "Top 8", sample "matches". The matchup matrix is symmetric (B vs A = 100 − A vs B).
- **Commander (cEDH):** baseline 25%. Labels: "Pod win rate", "Top 16", "Commander" instead of "Archetype", "pods" or "seats". The index title is "cEDH commanders" / "cEDH decklists". The matrix is not symmetric: a cell is the row commander's pod win rate when the column commander is in the same pod. Decks have a commander group plus "The 99" and no sideboard. Event kinds are labeled Webcam / Leagues / Paper, and a league finish shows "Trophy".
- **Vintage:** restricted cards are single copies. Nothing else changes.
- Mirrors are always "—" and excluded from win rates.
- 95% interval: `1.96 × √(p(1−p)/n) × 100`, where `p` is the baseline.

## Screens

### 1. Archetypes index
**Hero** (shared hero background: radial cyan glow at 80% 40% (accent / 0.11), a 24px grid of 1px lines at white/0.03, on `--bg-page`; padding 34px 32px 32px; flex, wraps, aligned to the bottom, space-between, gap 28px)
- Eyebrow "Metagame": mono 10px, letter-spacing .16em, uppercase, accent.
- H1 "{Format} archetypes": display (Cormorant Unicase) 64px, weight 500, line-height .95.
- Blurb at max-width 640px: 15.5px / 1.55, `--text-2`, `text-wrap: pretty`. Copy (1v1): "How each archetype performs in {Format}: share of the field, win rate with mirrors removed, and every matchup between the top decks."
- Stat strip: a bordered box (`--line-1`, radius 6, bg night-900 at 0.7) with 4 cells (padding 12px 18px, separated by 1px line-1): Archetypes, Decklists, Matches (cEDH: Games), Window. Labels are mono 9px .14em uppercase `--text-3`; values are mono 15px.

**Sticky toolbar** (top 60px, z 30, bg night-900 at 0.9 with 12px backdrop blur, bottom border line-1, min-height 58px): color filter segmented control (W U B R G C) on the left; window select (Last 14 / 30 / 90 days / Since last B&R) and source control (All / Online / Paper) on the right. Reuse the rankings controls.

**Archetype table** (card: line-1 border, radius 8, bg night-850 at 0.5; scrolls horizontally inside, min-width 980px)
- Grid columns: `44px minmax(240px,1fr) 170px 170px 96px 104px 150px`, column-gap 14px, padding 0 16px.
- Header row: 40px, `--surface-1`, mono 9px .12em uppercase `--text-3`. Columns: # · Archetype · Meta share · Win rate · Top 8 · Sample · Trend · 30d. Every column except # and Archetype sorts on click. The active column turns `--text-1` with ↓/↑, and a new column starts descending.
- Rows: 60px, line-1 top border, hover bg `--surface-2` (120ms), name turns accent on hover, whole row clicks through to detail.
  - #: mono 13px / 500 (rank by share).
  - Archetype: 10px color dots (gap 3; black dot gets an inset 1px `--mana-b-ring`), name 14px / 500 with ellipsis, "{n} lists" in mono 10px text-3 below.
  - Meta share: mono 12.5px value over a 120×4px bar (surface-2 track, accent fill with `0 0 6px var(--sigil-glow)`), width relative to the largest share.
  - Win rate: mono 12.5px. Accent if ≥ +0.5 vs field, danger if ≤ −0.5, otherwise text-1. Below it, mono 9.5px text-3: "±1.2 · +1.8 vs field".
  - Top 8: mono 12px "1.08×". Accent ≥ 1.10, danger < 0.97.
  - Sample: mono 12px text-2, thousands separators.
  - Trend: 64×24 sparkline (1.5px stroke, end dot r 2.25) plus a signed delta (mono 10.5px). Up (> +0.15) = accent, down (< −0.15) = danger, flat = text-3.
- Footer bar: 12px 16px, surface-1, mono 10.5px text-3: "{n} of {N} archetypes · win rate excludes mirrors · ± is the 95% interval".
- Empty state: "No archetypes match. Clear the color filter or search."

**Meta map + Share over time**: a two-column grid (`repeat(auto-fit, minmax(min(520px,100%),1fr))`, gap 24px). Each column has an eyebrow (mono 9.5px accent) and an H2 (display 32px / 600).
- *Meta map* ("Share × win rate" / "Meta map"): a 400px card (line-1, radius 8, bg night-850 at 0.6). The plot is inset left 56, right 28, top 22, bottom 44.
  - Horizontal gridlines: 4 y ticks (1px oklch(0.3 0.02 255)), labelled mono 9.5px text-3 to the left.
  - X ticks: 0/25/50/75/100% of the max share rounded up to 5.
  - Dashed line at the baseline, labelled "Even 50%" / "Pod baseline 25%" (mono 9px uppercase).
  - One dot per archetype. Diameter is `10 + √(sample/maxSample) × 16` px, filled with the archetype's mana colors (conic segments), ring `0 0 0 2px night-900`. On hover the ring becomes `0 0 0 2px accent, 0 0 18px sigil-glow`, the label turns accent, and the dot comes to the front.
  - Labels are 11.5px text-2, 7px right of the dot, or left of it when x > 66%.
  - Axis titles: "Meta share →" bottom-left, "Win rate →" vertical at the left.
  - Caption: "Dot size is sample size. Above the dashed line wins more than it loses." (12px text-3).
  - Clicking a dot opens the archetype.
- *Share over time* ("Weekly · top 6" / "Share over time"): the same 400px card.
  - SVG lines for the top 6 archetypes over 14 weekly points, y axis 0 to max rounded up to 5 (5 labels), gridlines at 25/50/75%.
  - Series colors, in rank order: `oklch(0.86 0.1 195)`, `oklch(0.8 0.12 80)`, `oklch(0.72 0.14 300)`, `oklch(0.78 0.13 150)`, `oklch(0.72 0.15 25)`, `oklch(0.75 0.1 250)`.
  - Strokes are 2px. The hovered series is 3px and the others drop to opacity .16 (140ms). End dots are 8px with a glow.
  - Ban-and-restriction marker: a dashed amber vertical line (warning at .75) with a pill label "Sep 30 · B&R" (warning wash, warning border at .4, mono 9px uppercase).
  - Legend: a grid of `minmax(210px,1fr)` items: 14×3 color swatch, name, current share (mono 11), signed 30-day trend (mono 10, colored). Hovering a legend item highlights its series and clicking opens the archetype. Hover state is shared between the table, the map, the chart and the legend.

**Matchup matrix** ("Row vs column" / "Matchup matrix", with a segmented toggle on the right: Win rate | Sample size)
- Card with line-1 border, radius 8, horizontal scroll. Grid columns: `minmax(180px,230px)` followed by N × 60px. Show up to the top 10 archetypes by share.
- Header row: 140px tall, surface-1. Column names are written vertically (`writing-mode: vertical-rl; transform: rotate(180deg)`), 12px. The corner cell reads "Win rate of row" (mono 9px uppercase).
- Row label: sticky left, 40px tall, color dots plus name 12.5px / 500. Clicking it opens the archetype.
- Cells: 40px, mono 11.5px, one decimal (sample mode: "1.2k").
  - Background: cyan `oklch(0.86 0.1 195 / α)` at or above even, red `oklch(0.7 0.16 25 / α)` below. `α = min(0.42, |wr − even| / 28)` (cEDH: `/ 18`).
  - Mirror cells show "—" on white/0.025.
  - Cells with fewer than 300 matches (cEDH: fewer than 120 pods) have their text at opacity .45.
  - Native tooltip: "{Row} vs {Col}: 54.2% over 1,240 matches (small sample)".
  - On cell hover: the cell gets an inset 1.5px accent ring, the rest of its row and column get an inset 1px white/0.1, and the row label and column header turn accent. Hover clears when the pointer leaves the matrix.
- Note below (12px text-3, max-width 760): "Each cell is the row archetype's match win rate against the column archetype. Faded cells have fewer than 300 matches." For cEDH: "…pod win rate when the column commander is in the same pod. 25% is even. Faded cells have fewer than 120 pods."

### 2. Archetype detail
- Breadcrumb: back button (30px, line-1 border, radius 4, 12.5px / 500, text-2, arrow icon) "{Format} archetypes", then mono 10.5px text-3 "/ {name}".
- Hero (margin-top 28, bottom border, padding-bottom 36; wraps; gap 28px 40px):
  - Left column: eyebrow "#3 by meta share in Modern", H1 64px / 500 / .96 with `text-wrap: balance`, 16px color dots, and two buttons (38px, padding 0 16px, radius 4). The primary button "View 4,124 decklists" (accent bg, text-on-accent, 13.5px / 600, `--glow-accent`, hover accent-hover) goes to `/decklists?archetype=`. The secondary button "Average list" (line-1 border, hover surface-2) opens the average list.
  - Right column: a 3×2 tile grid (gap 1px on line-1, radius 8). Each tile has padding 16px 18px on bg-page, a label (mono 9px uppercase text-3), a value (mono 24px) and a sub-line (12px text-3). Tiles: Meta share ("1,840 of 18,412 lists"), Win rate ("±0.8 at 95% confidence"), Vs field (accent or danger; "Mirror matches excluded"), Top 8 conversion ("Over-represented in Top 8s"), Sample ("matches played"), Trend · 30d ("+1.2 pts", "Change in meta share").
- "Over time" chart (eyebrow "Weekly · last 90 days"; tabs Meta share | Win rate). Same construction as the card-detail performance chart: 56px y-label column, 210px plot, cyan area gradient from .3 to 0, 2px line, dashed baseline only in win-rate mode ("Even 50%"), B&R marker, 10px end dot with halo, end pill "Oct 14 · 22.4%", 7 x labels.
- Two-column grid (`minmax(min(420px,100%),1fr)`, gap 24, aligned to the top):
  - **Core cards**: H3 display 24px / 600, with "{n} cards in nearly every list" on the right (mono 10.5px). Table columns `minmax(0,1fr) 70px 80px`: Card (name 13.5px / 500 plus 13px mana pips) · Copies (mono 12) · In lists (mono 12, text-2, e.g. "98.6%"). Rows 44px, hover surface-1. Nonland cards only, sorted by copies descending.
  - **Flex slots**: H3, with "With vs without" on the right. Horizontal scroll, min-width 560. Columns `minmax(150px,1fr) 64px 82px 82px 112px`, rows 52px:
    - Card: name plus "{x} avg copies" in mono 9.5 text-3.
    - In lists: % value over a 48×3 bar.
    - With: win rate plus "n 2,140".
    - Without: win rate in text-2 plus "n 3,060".
    - Difference: a 60×6 diverging bar centered on a 1px tick (width = min(30, |Δ|/3 × 30) px) plus the signed Δ in mono 11. The bar is accent if positive and significant, danger if negative and significant, text-3 (grey) if inside the 95% interval: `1.96 × √(q(1−q)/n_with + q(1−q)/n_without) × 100`.
    - Sorted by inclusion descending.
    - Footer note: "Win rate of matches where the deck ran the card versus where it didn't. Grey means the gap is inside the 95% interval."
  - Hovering any card row in either table shows the card preview (see Decklist detail).
- **Matchups** (cEDH: "Pod win rate with each commander"): a tile grid `repeat(auto-fill,minmax(170px,1fr))`, gap 1px on line-1. Each tile has dots, opponent name (13px text-2), win rate (mono 24, accent at +2 or more, danger at −2 or less) and sample (mono 9.5), with the matrix's tint as background at α = min(0.3, |Δ|/40). Clicking opens that archetype.
- **Top lists**: H3 with an "All decklists →" link (accent 12.5px). Rows hold: finish badge · player (13.5 / 500) · event (12.5 text-2) · date · record · price (mono 12, right-aligned). Up to 8, best finish first. Empty state: "No top finishes in the last two weeks."

### 3. Decklists index
- Hero: eyebrow "Tournament results", H1 "{Format} decklists" (cEDH: "cEDH decklists"), blurb "Top finishes and 5-0 league lists from the last two weeks. Search a player, archetype or any card in the 75." Stats: Lists · Events · Archetypes · Dates.
- Sticky toolbar (padding 12px 32px, wraps, gap 10px 14px), left to right:
  - Event segmented control: All events / Challenges (cEDH: Webcam) / Leagues / Paper.
  - Archetype select: "All archetypes" plus each archetype; max-width 230.
  - Finish select: Any finish / Top 4 only / Winners only.
  - Color filter.
  - Spacer.
  - Source control: All / Online / Paper.
  - Sort select: Newest first / Best finish / Price: high to low / Price: low to high.
  - Selects follow the existing pattern: 34px, surface-1, line-1 border, radius 4, 12.5px, custom chevron, `color-scheme: dark`.
- Table (min-width 900, horizontal scroll). Columns `84px minmax(230px,1.3fr) minmax(220px,1fr) 64px 70px 110px`, gap 16. Header: Finish · Deck (cEDH: Commander) · Event · Date · Record · Price.
  - Rows are at least 62px tall, hover surface-2, and click through to detail.
  - **Finish badge**: 24px tall, min-width 56, radius 4, mono 11px / 500. "1st" uses accent bg, text-on-accent and `--glow-accent`. "5-0" and "Trophy" use sigil-wash bg, sigil-line border and accent text. Everything else uses surface-2 bg, line-1 border and text-1.
  - Deck cell: dots, archetype 14 / 500, player 12 text-3. When the search matches a card (query of 3 or more characters), add a chip under the player: mono 10px, sigil-wash bg and sigil-line border, accent text, e.g. "4× Lightning Bolt · 1× Fiery Islet".
  - Price cell: "$1,284" (mono 12.5) over "312 tix" (mono 9.5 text-3), right-aligned.
- Footer: "Showing {n} of {N} lists", plus " · matching card copies shown under each player" when a card search is active.
- Empty state: display 24px "No decklists match.", 14px text-2 "Loosen a filter or search a different player or card.", and a "Clear filters" button.
- The search matches archetype, player, event and (with 3 or more characters) any card in the main deck, sideboard or commander zone.

### 4. Decklist detail (also used for the average list)
- Breadcrumb "{Format} decklists / {Archetype} by {player}" (average list: "{Archetype} · average list").
- Header row (wraps, aligned to the bottom, space-between; bottom border):
  - Left side:
    - Eyebrow: "1st · MTGO Modern Challenge 64 · Oct 13". Average list: "Average list · built from the most common card choices".
    - H1: archetype name, 60px / 500. Clicking it opens the archetype page; it turns accent on hover.
    - Deck color pips (20px), from nonland mana costs in WUBRG order.
    - Byline (15px text-2): "by ashvale · 8-1 · 64 players". Average list: "Most common configuration across recent {Archetype} lists".
  - Right side, gap 10:
    - Text | Visual segmented control (34px).
    - Export group: a bordered box holding the label "Export" (mono 9px uppercase text-3) and the buttons Arena · MTGO · Text (34px, left divider, hover surface-2). Each button copies to the clipboard and shows the toast "Arena list copied" (and so on).
    - Primary "Copy link" button (36px, link icon) copies the canonical `/decklists/[id]` URL and shows the toast "Link copied".
- Body: flex, wraps, gap 32. The main column is `flex: 1 1 620px`. The aside is `flex: 0 1 330px; min-width: 280px; position: sticky; top: 84px`.
- **Main column**: H2 "Main deck" (cEDH: "The 99") at display 28 / 600, plus a count (mono 12 text-3).
  - **Text view**: CSS columns `2 300px`, gap 28. Groups don't break across columns. Group order: (Commander/Commanders,) Creatures, Planeswalkers, Instants, Sorceries, Artifacts, Enchantments, Battles, Lands.
    - Group header: mono 9.5 .14em uppercase text-3, label and total, bottom border line-1, padding 0 10px 8px.
    - Rows: 32px, grid `22px minmax(0,1fr) auto 62px`. Count (mono 12 text-2), name (13.5, ellipsis), 13px pips (none for lands), line price (mono 10.5 text-3, count × unit price; "$4.20", or "$1,284" from $100 up). Hover bg surface-2, radius 4.
    - Rows are sorted by mana value, then name.
    - The sideboard follows under its own H2 with a count, in the same row style.
  - **Visual view**: one block per group with a small header, then a grid `repeat(auto-fill,minmax(112px,1fr))`, gap 14px 12px (sideboard: 96px cards).
    - Each card is 63:88, radius 4.75%/3.4%, line-2 border, and uses the real card image via `card-image.tsx` (the prototype shows striped placeholders).
    - Extra copies show as stacked slivers below the card: for each copy after the first (up to 4 in total), `0 {7k}px 0 -1px var(--surface-2), 0 {7k}px 0 0 var(--line-2)`, with a matching bottom margin.
    - A count badge sits top-right: 20px pill, night-900 bg, line-2 border, mono 10.5.
    - Hover lifts the card 4px and turns its border to accent at .7 (180ms `cubic-bezier(0.2,0.7,0.2,1)`).
- **Aside**: four cards, each with padding 18, line-1 border, radius 8 and surface-1 bg.
  1. **Price** (with an extra radial cyan wash): total paper price "$1,284" (mono 26) next to "312 tix" (mono 14 text-2). Below: "Main $1,180 · Side $104 · paper / MTGO" (cEDH: "Commander + 99"), then the 3 most expensive lines ("4× · $192.00").
  2. **Mana curve**: header plus "avg 1.84". Seven bars for mana value 0–6+ (grid of 7, gap 8, 118px tall; bar max height 78px, radius 3px 3px 0 0) with the count above each bar and the label below. The tallest bar uses an accent gradient (accent to accent at .3) with a glow. The others use `linear-gradient(oklch(0.5 0.02 255), oklch(0.32 0.02 255))`. Caption: "{n} nonland cards by mana value".
  3. **Card types**: an 8px stacked bar (2px gaps, radius 4) and a 2-column legend: swatch, plural label, count. Type colors: creature `oklch(0.86 0.1 195)`, planeswalker `oklch(0.72 0.14 300)`, instant `oklch(0.75 0.1 250)`, sorcery `oklch(0.72 0.15 25)`, artifact `oklch(0.72 0.016 255)`, enchantment `oklch(0.8 0.12 80)`, battle `oklch(0.78 0.13 150)`, land `oklch(0.45 0.02 255)`.
  4. **Vs. average list**: header plus an "Open average" link (accent 12). Note: "{n} changes from the {Archetype} average list", or "Card for card the same as the average list.", or, on the average list itself, "This is the average list. Open any decklist to see how it differs." Rows are 28px: signed delta (+2 in success, −2 in danger, mono 12), card name, zone ("Main" / "Side", mono 9 uppercase). Main rows come first, then by delta descending. Hovering a row shows the card preview.
- **Card hover preview**: fixed position, z 80, 222px wide, padding 12, surface-2 bg, line-2 border, radius 8, `--shadow-pop`, no pointer events.
  - Contents: the card image (63:88, cyan border at .5 and glow), the type and mana pips, then a divider and a mono 10.5 line "$4.20 · 1.10 tix" with "#12 in Modern" and the card's grade letter in its grade color (or "Not ranked in Modern").
  - Placement: 14px to the right of the hovered row, or 236px to its left if it would overflow. Vertically centered on the row and clamped between 70px and viewport height − 340px.
  - Used by the decklist text rows, the average-list diff rows, and the archetype core/flex rows. A shared `<CardHoverPreview>` built on `tooltip.tsx` is the expected implementation.
- **Toast**: reuse `toast.tsx`. In the prototype it sits at bottom center, 40px tall, with a sigil-line border, surface-2 bg, a check icon in accent and 13px / 500 text, and disappears after 1.9s.

## Export formats (exact)
- **Arena**: `Deck\n4 Card Name\n…` then `\n\nSideboard\n2 Card Name\n…`. Commander: `Commander\n1 X\n\nDeck\n1 …`.
- **MTGO**: main deck lines, a blank line, then sideboard lines. Commander puts the commanders in the sideboard block.
- **Text**: `// {Archetype} by {player} · {finish}, {event}, {date}`, then `// Main (60)` with its lines, then `\n\n// Sideboard (15)` with its lines. Commander adds `// Commander` first.

## Interactions & state
- Every filter lives in the URL search params (format, window, source, colors, event, archetype, finish, sort, q, view=text|visual, chart=share|wr, matrix=wr|n) so that views can be shared and the back button works. This matches the existing rankings page.
- Hover-only state (highlighted archetype, matrix cell, card preview) stays on the client. Keep the interactive pieces in small client components and the pages themselves as server components.
- Transitions: row background 120ms, chart opacity 140ms, card lift 180ms `cubic-bezier(0.2,0.7,0.2,1)`.
- Loading and error states: reuse `app/loading.tsx` / `problem.tsx`. An empty filter result shows the empty states above.
- Responsive: tables keep their min-widths inside horizontal scroll containers, the chart pairs collapse to one column below about 1100px, and the decklist aside drops under the list when the row wraps.

## Design tokens
These are already in the codebase from the restyle (`web/src/app/tokens.css`). Use the variables.
- Surfaces: `--bg-deep` oklch(0.145 0.013 255), `--bg-page` oklch(0.165 0.014 255), night-850 oklch(0.185 0.015 255), `--surface-1` oklch(0.21 0.016 255), `--surface-2` oklch(0.25 0.018 255), `--line-1` oklch(0.33 0.02 255), `--line-2` oklch(0.4 0.02 255).
- Text: `--text-1` (star-50, ≈ oklch(0.94 0.008 255)), `--text-2` (star-200), `--text-3` (star-300, ≈ oklch(0.72 0.016 255)), `--text-on-accent` = night-900.
- Accent: `--accent` oklch(0.86 0.1 195), `--accent-hover` (sigil-200), `--sigil-glow` /0.55, `--sigil-wash` /0.14, `--sigil-line` /0.32.
- Feedback: `--success` oklch(0.78 0.12 160), `--warning` oklch(0.8 0.12 80), `--danger` oklch(0.7 0.16 25).
- Mana: `--mana-w` oklch(0.93 0.05 95), `--mana-u` oklch(0.74 0.13 250), `--mana-b` oklch(0.32 0.04 300) with ring oklch(0.6 0.05 300), `--mana-r` oklch(0.72 0.15 35), `--mana-g` oklch(0.74 0.13 150), `--mana-c` oklch(0.7 0.012 255), `--mana-ink` night-900.
- Effects: `--shadow-pop` 0 12px 24px −10px black/.75, `--shadow-card` 0 10px 18px −12px black/.7, `--glow-accent` 0 0 0 1px accent/.5 plus 0 0 24px −4px accent/.55. Placeholder stripes `--ph-a`/`--ph-b`.
- Type: display `Cormorant Unicase` (H1 60–64px / 500, H2 28–32px / 600, H3 24px / 600), UI `Hanken Grotesk` (12–15.5px), data `Martian Mono` (9–26px; uppercase labels at 9–10px with .12–.16em tracking).
- Radii: 3 (chips), 4 (buttons, inputs), 6 (segmented controls, stat strips), 8 (cards, tables).

## Assets
No new assets. Card art uses the existing `card-image.tsx` (the prototype shows striped placeholders that say "card image"). Mana symbols use the existing `mana.tsx` (the prototype uses lettered pips). Icons: the arrow-left, link and check glyphs are 24-viewBox stroke icons at 2px, available through `icon.tsx`.

## Files in this bundle
- `design/Card Rankings.dc.html`: the full prototype. The new screens live in the same file as rankings and compare. In the logic class, look at `archCtx`, `archIndexVals`, `archDetailVals`, `deckPool`, `deckList`, `deckIndexVals`, `deckDetailVals`, `lineChart` and `hoverCard` for the exact derivations. The sample decklists are `ls_<format>`, and the Commander pool is in `edh`.
- `design/styles.css`, `design/tokens/*.css`, `design/fonts/*`: the visual system, used only so the prototype renders.
- `design/support.js`: the prototype runtime. Not needed in the app.
