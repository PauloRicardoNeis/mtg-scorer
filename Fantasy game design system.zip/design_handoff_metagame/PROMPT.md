# Paste this into Claude Code (run from the repo root)

---

Implement the new **Archetypes** and **Decklists** sections for the web app (`web/`, Next.js App Router), following the design handoff in `design_handoff_metagame/`.

Live design (open in a browser if you can; it may require a claude.ai login):
https://claude.ai/design/p/cd971fb3-6f54-4b06-9112-02fc89195645?file=Card+Rankings.dc.html&via=share
If the link isn't reachable, open `design_handoff_metagame/design/Card Rankings.dc.html` locally instead. It is the same prototype. Use the top nav to reach Decklists and Archetypes, and click rows to open detail pages.

Steps:
1. Read `design_handoff_metagame/README.md` in full before writing code. It is the spec: layout, exact values, copy, format rules (1v1 vs. cEDH), export formats and states.
2. Explore the existing app first and reuse it: `web/src/lib/api.ts` (the `read<T>()` pattern), `web/src/app/rankings/page.tsx` (search params, format tabs, window/source filters), and `web/src/components/` (`site-nav.tsx`, `mana.tsx`, `card-image.tsx`, `filters.tsx`, `tooltip.tsx`, `toast.tsx`, `icon.tsx`, `header-search.tsx`). Style with the existing tokens and classes in `web/src/app/tokens.css` / `styles.css`. Don't add new hard-coded colors where a token exists.
3. Add the routes `/archetypes`, `/archetypes/[archetype]`, `/archetypes/[archetype]/average`, `/decklists` and `/decklists/[deck_id]`. Add "Decklists" and "Archetypes" to the site nav before Methodology. All filters and toggles live in the URL search params.
4. Data: the API has no archetype, matchup or decklist endpoints yet. Create `web/src/lib/metagame.ts` with the types from the README, plus `api.archetypes / archetype / decklists / decklist` functions in the `api.ts` style. Back them for now with a typed fixture module (`metagame.fixtures.ts`) and show the existing "Sample data" pill. Do not change the Java API.
5. Keep pages as server components. Put only the interactive parts (hover highlighting, matrix hover, card hover preview, export/copy buttons, Text/Visual toggle) in small client components.
6. Add tests next to the new components in the repo's existing style (`*.test.tsx`). Cover: export text formats, matrix symmetry for 1v1 and mirror "—", the with/without significance rule, the diff vs. average, and card-name search on the decklists index.
7. Run the existing lint, typecheck and test scripts and fix anything you broke. Don't change the rankings, cards or datasets pages except for the shared nav.

When done, list the files you added or changed and anything you couldn't match from the design.
